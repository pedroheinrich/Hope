#ifndef INTERRUPT_H
#define INTERRUPT_H

#include "defs.h"

extern	void	disable_interrupt(void);
extern	void	enable_interrupt(void);

#endif
