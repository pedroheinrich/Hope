#ifndef	FUNCTOR_TYPE_H
#define	FUNCTOR_TYPE_H

#include "defs.h"

/*
 *	Generate types of 'functors'.
 */

extern	Cell	*functor_type(DefType *dt);

#endif
