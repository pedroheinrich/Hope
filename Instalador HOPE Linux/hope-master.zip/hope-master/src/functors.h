#ifndef FUNCTORS_H
#define FUNCTORS_H

#include "defs.h"

/*
 *	Definition of 'functors'.
 */

extern	void	def_functor(DefType *dt);

#endif
