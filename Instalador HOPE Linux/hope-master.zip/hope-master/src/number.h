#ifndef NUMBER_H
#define NUMBER_H

#include "defs.h"

/*
 *	Resolve identifiers.
 */

extern	Bool	nr_branch(Branch *branch);

#endif
