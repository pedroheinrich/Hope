hope
====

Hope is a lazily evaluated functional programming language developed in 1970's
by Ross Paterson. It influenced the design of other lazy languages such as 
Miranda and Haskell.

This version is derived from the source that was once available from the author's
home page (http://web.archive.org/web/20110709142512/http://www.soi.city.ac.uk/~ross/Hope/).

The goal of this project is to preserve Hope in its original form, so the only changes
being made are fixes required to get it to build on modern systems.
