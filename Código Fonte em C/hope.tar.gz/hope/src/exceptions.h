#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

#include <setjmp.h>

extern	jmp_buf	execerror;

#endif
