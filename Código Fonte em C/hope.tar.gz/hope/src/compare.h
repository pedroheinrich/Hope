#ifndef COMPARE_H
#define COMPARE_H

#include "defs.h"

/*
 *	Set up comparison code
 *	Call after reading standard module.
 */
extern	void	init_cmps(void);

#endif
