#define HOPELIB "/usr/local/share/hope/lib"
